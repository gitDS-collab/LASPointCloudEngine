# LAS / PLY Point Cloud Engine V9 — Revit 2027

This package installs the LAS / PLY Point Cloud Engine for **Autodesk Revit 2027** for the current Windows user. It includes the existing LAS preview and ReCap workflow, plus a safe PLY vertex-cloud workflow that prepares its preview outside Revit.

## Requirements

- Windows with **Autodesk Revit 2027** installed.
- Revit must be fully closed before installation.
- No administrator account is required.
- An uncompressed `.las` file for direct LAS linking. Compressed `.laz` is not supported.
- For PLY: a local, on-device `.ply` file in PLY 1.0 **ASCII** or **binary little-endian** format, with `vertex` as its first element and scalar `x`, `y`, `z` properties. RGB is optional.
- PLY coordinates are treated as **metres**, because PLY has no standard unit field. Check the scale against a known Revit dimension before relying on it.
- Autodesk ReCap Pro remains optional for direct LAS/PLY preview. It is required only for **Create Indexed RCP from LAS**, which remains LAS-only.

PLY meshes are imported as **vertices only**. Faces, normals, textures, material information, and other PLY elements are intentionally ignored.

## Install

1. Download and extract the entire ZIP to a local folder. Do not run the installer inside the ZIP preview window.
2. Close every Revit 2027 window and wait for `Revit.exe` to exit.
3. Right-click `Install-LASPointCloudEngine.ps1` and choose **Run with PowerShell**. If Windows asks for confirmation, approve it.
4. If script execution is blocked, open PowerShell in the extracted folder and run:

   ```powershell
   powershell -ExecutionPolicy Bypass -File .\Install-LASPointCloudEngine.ps1
   ```

5. Wait for the green success message, then start Revit 2027.
6. Open a project and select the **LAS Point Cloud** ribbon tab.

The installer checks the SHA-256 payload list, verifies the PLY cache helper can start, stages the full add-in first, then activates it at:

```text
%APPDATA%\Autodesk\Revit\Addins\2027\LASPointCloudEngine-v9-ply-visibility
```

It updates `%APPDATA%\Autodesk\Revit\Addins\2027\LASPointCloudEngine.addin` only after staging succeeds. The prior manifest and any previous same-version folder are retained as timestamped backups.

## Import a PLY file

1. In Revit, choose **LAS Point Cloud** → **Import LAS / PLY Point Cloud**.
2. Select your `.ply` file.
3. On first use, choose **Start PLY Preview Cache Builder**. A separate console scans the PLY outside Revit; Revit remains responsive.
4. Wait for the console to say **Ready**. Do not close it early.
5. Run **Import LAS / PLY Point Cloud** again and select the same file.

The helper stores the local preview cache here:

```text
%LOCALAPPDATA%\LASPointCloudEngine\Cache
```

It keeps the original PLY unchanged. The preview contains up to **1,000,000 spatially balanced vertices**; it is designed to avoid the Revit freeze caused by drawing every point from a very dense raw PLY. If the source PLY changes, rerun the helper before reloading/linking it. Keep the original PLY and the local cache available on any computer that opens a project with that PLY link.

V9 also fixes point clouds that were invisible until selected or hovered: PLY vertices with no colour, or with pure-white RGB commonly used as a no-colour sentinel, are rendered dark for visibility on Revit's normal white canvas. Existing preview caches are corrected when Revit next opens the project; rebuilding the cache is not required for this fix.

## Revit commands

- **Import LAS / PLY Point Cloud** — links an uncompressed LAS directly, or a prepared PLY preview cache.
- **Create Indexed RCP from LAS** — runs the installed ReCap converter with zero requested decimation. This command is intentionally LAS-only.
- **Link Indexed RCP/RCS** — links a completed native ReCap dataset.
- **RCP Indexing Progress** — shows the conversion/indexing state of a ReCap job started in the current Revit session.

## Troubleshooting

- **The PLY helper is missing:** reinstall from the full extracted V9 ZIP. Confirm that `cache-builder\LASPointCloudCacheBuilder.exe` exists under the V9 add-in folder.
- **The helper will not start:** run the installer again. Its preflight checks the Microsoft .NET 10 runtime used by Revit 2027.
- **Cache is stale or missing:** run Import LAS / PLY again, select the PLY, and start the cache builder. This is expected after a PLY is edited, moved, replaced, or the local cache is cleared.
- **PLY appears only when selected or hovered:** close and reopen Revit after installing V9, then reopen the project. V9 renders all-white and uncoloured PLY points in a visible dark colour.
- **Cloud-only OneDrive file:** in File Explorer choose **Always keep on this device** for the PLY before building its cache.
- **Scale is wrong:** PLY has no universal unit metadata. This release assumes metres; re-export or transform the source if your scan is in another unit.

## Package contents

- `Install-LASPointCloudEngine.ps1` — current-user installer with backups, integrity checks, and Revit-process guard.
- `payload` — deployable Revit add-in, manifest template, icons, and the PLY cache helper.
- `source` — full C# source used to build the release, including the shared PLY parser and cache-builder project.
- `checksums.sha256` — SHA-256 integrity list verified by the installer.
