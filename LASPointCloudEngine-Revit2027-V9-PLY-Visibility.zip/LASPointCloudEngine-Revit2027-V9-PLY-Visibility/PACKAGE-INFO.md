# LAS / PLY Point Cloud Engine V9 package

- Target application: Autodesk Revit 2027
- Build: V9 — safe PLY 1.0 vertex-cloud support with normal-display and white-colour visibility fixes
- Installer scope: current Windows user only
- Main assembly: `payload\LASPointCloudEngine.dll`
- Deployment folder: `%APPDATA%\Autodesk\Revit\Addins\2027\LASPointCloudEngine-v9-ply-visibility`
- PLY cache helper: `payload\cache-builder\LASPointCloudCacheBuilder.exe`
- Payload verification: `checksums.sha256` (SHA-256)

Supported PLY input: ASCII or binary little-endian PLY 1.0, vertex-first scalar `x/y/z`, optional RGB. PLY units are assumed to be metres; mesh data is not imported. See `INSTALL.md` before running the installer.
