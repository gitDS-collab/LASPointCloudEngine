using System;
using System.Buffers.Binary;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace LASPointCloudEngine.Ply;

/// <summary>
/// A strict, dependency-free reader for the vertex portion of PLY 1.0 files.
/// It deliberately ignores mesh faces and other trailing elements: this add-in renders vertices
/// as a point cloud, not PLY mesh geometry.
/// </summary>
public sealed class PlyFileHeader
{
    private const int MaximumHeaderBytes = 1024 * 1024;
    private const int MaximumHeaderLineBytes = 16 * 1024;
    private const int MaximumVertexProperties = 128;
    private const int MaximumAsciiVertexLineBytes = 64 * 1024;

    private readonly PlyProperty[] _properties;
    private readonly PlyProperty _xProperty;
    private readonly PlyProperty _yProperty;
    private readonly PlyProperty _zProperty;
    private readonly PlyProperty? _redProperty;
    private readonly PlyProperty? _greenProperty;
    private readonly PlyProperty? _blueProperty;

    private PlyFileHeader(
        PlyEncoding encoding,
        long dataOffset,
        long vertexCount,
        int binaryVertexStride,
        string headerFingerprint,
        PlyProperty[] properties,
        PlyProperty xProperty,
        PlyProperty yProperty,
        PlyProperty zProperty,
        PlyProperty? redProperty,
        PlyProperty? greenProperty,
        PlyProperty? blueProperty)
    {
        Encoding = encoding;
        DataOffset = dataOffset;
        VertexCount = vertexCount;
        BinaryVertexStride = binaryVertexStride;
        HeaderFingerprint = headerFingerprint;
        _properties = properties;
        _xProperty = xProperty;
        _yProperty = yProperty;
        _zProperty = zProperty;
        _redProperty = redProperty;
        _greenProperty = greenProperty;
        _blueProperty = blueProperty;
    }

    public PlyEncoding Encoding { get; }
    public long DataOffset { get; }
    public long VertexCount { get; }
    public int BinaryVertexStride { get; }
    public string HeaderFingerprint { get; }

    /// <summary>
    /// Reads and validates only the bounded PLY header. Vertex data is intentionally not scanned
    /// here; the external cache builder performs full scans away from Revit graphics callbacks.
    /// </summary>
    public static PlyFileHeader Read(string path)
    {
        if ((File.GetAttributes(path) & FileAttributes.Offline) != 0)
        {
            throw new InvalidDataException(
                "The PLY file is cloud-only. In OneDrive choose 'Always keep on this device' " +
                "or make a local copy before preparing it.");
        }

        FileInfo info = new(path);
        if (info.Length < 16)
            throw new InvalidDataException("The selected file is too small to contain a PLY header.");

        using FileStream stream = OpenStream(path, FileOptions.SequentialScan);
        byte[] lineBuffer = new byte[MaximumHeaderLineBytes];
        int headerBytes = 0;

        string firstLine = ReadHeaderLine(stream, lineBuffer, ref headerBytes);
        if (!string.Equals(firstLine, "ply", StringComparison.Ordinal))
            throw new InvalidDataException("The selected file is not a PLY file.");

        PlyEncoding? encoding = null;
        bool seenFirstElement = false;
        bool inVertexElement = false;
        bool seenVertexElement = false;
        long vertexCount = 0;
        int binaryStride = 0;
        List<PlyProperty> vertexProperties = new();

        while (true)
        {
            string line = ReadHeaderLine(stream, lineBuffer, ref headerBytes);
            if (string.IsNullOrWhiteSpace(line))
                continue;

            string[] tokens = line.Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries);
            string keyword = tokens[0];
            if (string.Equals(keyword, "comment", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(keyword, "obj_info", StringComparison.OrdinalIgnoreCase))
            {
                continue;
            }

            if (string.Equals(keyword, "format", StringComparison.OrdinalIgnoreCase))
            {
                if (encoding is not null || tokens.Length != 3 || !string.Equals(tokens[2], "1.0", StringComparison.Ordinal))
                    throw new InvalidDataException("Only well-formed PLY 1.0 headers are supported.");

                encoding = tokens[1].ToLowerInvariant() switch
                {
                    "ascii" => PlyEncoding.Ascii,
                    "binary_little_endian" => PlyEncoding.BinaryLittleEndian,
                    "binary_big_endian" => throw new InvalidDataException(
                        "Binary big-endian PLY is not supported. Export a binary little-endian or ASCII PLY file."),
                    _ => throw new InvalidDataException(
                        "Only ASCII and binary little-endian PLY 1.0 files are supported."),
                };
                continue;
            }

            if (string.Equals(keyword, "element", StringComparison.OrdinalIgnoreCase))
            {
                if (encoding is null || tokens.Length != 3)
                    throw new InvalidDataException("The PLY header has an invalid element declaration.");

                string elementName = tokens[1];
                if (!seenFirstElement && !string.Equals(elementName, "vertex", StringComparison.OrdinalIgnoreCase))
                {
                    throw new InvalidDataException(
                        "The PLY vertex element must be the first element so it can be prepared safely.");
                }

                seenFirstElement = true;
                inVertexElement = string.Equals(elementName, "vertex", StringComparison.OrdinalIgnoreCase);
                if (!inVertexElement)
                    continue;

                if (seenVertexElement || !long.TryParse(tokens[2], NumberStyles.None, CultureInfo.InvariantCulture, out vertexCount) || vertexCount < 1)
                    throw new InvalidDataException("The PLY vertex count is invalid.");

                seenVertexElement = true;
                continue;
            }

            if (string.Equals(keyword, "property", StringComparison.OrdinalIgnoreCase))
            {
                if (!seenFirstElement)
                    throw new InvalidDataException("The PLY header declares a property before an element.");
                if (!inVertexElement)
                    continue;

                if (tokens.Length >= 2 && string.Equals(tokens[1], "list", StringComparison.OrdinalIgnoreCase))
                {
                    throw new InvalidDataException(
                        "PLY vertex list properties are not supported. Export scalar x/y/z vertex coordinates.");
                }
                if (tokens.Length != 3 || vertexProperties.Count >= MaximumVertexProperties || !TryParseScalarType(tokens[1], out PlyScalarType type))
                    throw new InvalidDataException("The PLY vertex property declaration is unsupported or damaged.");

                string name = tokens[2].ToLowerInvariant();
                if (vertexProperties.Exists(property => string.Equals(property.Name, name, StringComparison.Ordinal)))
                    throw new InvalidDataException($"The PLY header contains duplicate vertex property '{tokens[2]}'.");

                int offset = binaryStride;
                try { binaryStride = checked(binaryStride + GetScalarSize(type)); }
                catch (OverflowException) { throw new InvalidDataException("The PLY vertex record is too large."); }
                vertexProperties.Add(new PlyProperty(name, type, vertexProperties.Count, offset));
                continue;
            }

            if (string.Equals(keyword, "end_header", StringComparison.OrdinalIgnoreCase))
            {
                if (tokens.Length != 1)
                    throw new InvalidDataException("The PLY end_header declaration is invalid.");
                break;
            }

            throw new InvalidDataException($"The PLY header directive '{tokens[0]}' is unsupported.");
        }

        if (encoding is null || !seenVertexElement || vertexProperties.Count == 0)
            throw new InvalidDataException("The PLY file is missing its format or vertex declaration.");

        PlyProperty xProperty = GetRequiredProperty(vertexProperties, "x");
        PlyProperty yProperty = GetRequiredProperty(vertexProperties, "y");
        PlyProperty zProperty = GetRequiredProperty(vertexProperties, "z");
        PlyProperty? redProperty = GetColorProperty(vertexProperties, "red", "r");
        PlyProperty? greenProperty = GetColorProperty(vertexProperties, "green", "g");
        PlyProperty? blueProperty = GetColorProperty(vertexProperties, "blue", "b");
        if ((redProperty is null) != (greenProperty is null) || (redProperty is null) != (blueProperty is null))
        {
            redProperty = null;
            greenProperty = null;
            blueProperty = null;
        }

        long dataOffset = headerBytes;
        if (dataOffset >= info.Length)
            throw new InvalidDataException("The PLY file has no readable vertex data.");

        if (encoding == PlyEncoding.BinaryLittleEndian)
        {
            long bytesRequired;
            try { bytesRequired = checked(vertexCount * (long)binaryStride); }
            catch (OverflowException) { throw new InvalidDataException("The PLY vertex data size is invalid."); }
            if (binaryStride < 1 || bytesRequired > info.Length - dataOffset)
                throw new InvalidDataException("The PLY file has no complete readable vertex records.");
        }

        string fingerprint = ComputeHeaderFingerprint(path, checked((int)dataOffset));
        return new PlyFileHeader(
            encoding.Value,
            dataOffset,
            vertexCount,
            binaryStride,
            fingerprint,
            vertexProperties.ToArray(),
            xProperty,
            yProperty,
            zProperty,
            redProperty,
            greenProperty,
            blueProperty);
    }

    /// <summary>
    /// Scans every declared vertex. Call only from the external cache builder, never from Revit's
    /// display/query callbacks.
    /// </summary>
    public void ScanPoints(string path, Action<PlyPoint> visitor)
    {
        ArgumentNullException.ThrowIfNull(visitor);
        if (Encoding == PlyEncoding.BinaryLittleEndian)
            ScanBinaryPoints(path, visitor);
        else
            ScanAsciiPoints(path, visitor);
    }

    private void ScanBinaryPoints(string path, Action<PlyPoint> visitor)
    {
        using FileStream stream = OpenStream(path, FileOptions.SequentialScan);
        stream.Seek(DataOffset, SeekOrigin.Begin);
        byte[] record = new byte[BinaryVertexStride];
        for (long index = 0; index < VertexCount; index++)
        {
            ReadExactly(stream, record, record.Length, "Unexpected end of binary PLY vertex data.");
            visitor(ReadBinaryPoint(record));
        }
    }

    private void ScanAsciiPoints(string path, Action<PlyPoint> visitor)
    {
        using FileStream stream = OpenStream(path, FileOptions.SequentialScan);
        stream.Seek(DataOffset, SeekOrigin.Begin);
        byte[] lineBuffer = new byte[MaximumAsciiVertexLineBytes];
        for (long index = 0; index < VertexCount; index++)
        {
            string line = ReadDataLine(stream, lineBuffer);
            visitor(ReadAsciiPoint(line));
        }
    }

    private PlyPoint ReadBinaryPoint(ReadOnlySpan<byte> record)
    {
        double x = ReadBinaryScalar(record, _xProperty);
        double y = ReadBinaryScalar(record, _yProperty);
        double z = ReadBinaryScalar(record, _zProperty);
        return CreatePoint(x, y, z, ReadColor(record));
    }

    private PlyPoint ReadAsciiPoint(string line)
    {
        string[] values = line.Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries);
        if (values.Length != _properties.Length)
            throw new InvalidDataException("An ASCII PLY vertex record has the wrong number of values.");

        double x = ReadAsciiScalar(values[_xProperty.Index], _xProperty.Type);
        double y = ReadAsciiScalar(values[_yProperty.Index], _yProperty.Type);
        double z = ReadAsciiScalar(values[_zProperty.Index], _zProperty.Type);
        return CreatePoint(x, y, z, ReadColor(values));
    }

    private PlyPoint CreatePoint(double x, double y, double z, int color)
    {
        if (!double.IsFinite(x) || !double.IsFinite(y) || !double.IsFinite(z))
            throw new InvalidDataException("The PLY file contains a non-finite vertex coordinate.");
        return new PlyPoint(x, y, z, PlyPointColor.NormalizeForRevit(color));
    }

    private int ReadColor(ReadOnlySpan<byte> record)
    {
        if (_redProperty is null || _greenProperty is null || _blueProperty is null)
            return 0x00ffffff;

        int red = ToColorByte(ReadBinaryScalar(record, _redProperty.Value), _redProperty.Value.Type);
        int green = ToColorByte(ReadBinaryScalar(record, _greenProperty.Value), _greenProperty.Value.Type);
        int blue = ToColorByte(ReadBinaryScalar(record, _blueProperty.Value), _blueProperty.Value.Type);
        return red | (green << 8) | (blue << 16);
    }

    private int ReadColor(string[] values)
    {
        if (_redProperty is null || _greenProperty is null || _blueProperty is null)
            return 0x00ffffff;

        int red = ToColorByte(ReadAsciiScalar(values[_redProperty.Value.Index], _redProperty.Value.Type), _redProperty.Value.Type);
        int green = ToColorByte(ReadAsciiScalar(values[_greenProperty.Value.Index], _greenProperty.Value.Type), _greenProperty.Value.Type);
        int blue = ToColorByte(ReadAsciiScalar(values[_blueProperty.Value.Index], _blueProperty.Value.Type), _blueProperty.Value.Type);
        return red | (green << 8) | (blue << 16);
    }

    private static int ToColorByte(double value, PlyScalarType type)
    {
        if (!double.IsFinite(value))
            throw new InvalidDataException("The PLY file contains a non-finite color component.");

        double scaled = type switch
        {
            PlyScalarType.UInt16 => value / 257.0,
            PlyScalarType.UInt32 => value * 255.0 / uint.MaxValue,
            PlyScalarType.Int16 => value * 255.0 / short.MaxValue,
            PlyScalarType.Int32 => value * 255.0 / int.MaxValue,
            PlyScalarType.Float32 or PlyScalarType.Float64 when value >= 0 && value <= 1 => value * 255.0,
            _ => value,
        };
        return (int)Math.Clamp(Math.Round(scaled, MidpointRounding.AwayFromZero), 0, 255);
    }

    private static double ReadBinaryScalar(ReadOnlySpan<byte> record, PlyProperty property) => property.Type switch
    {
        PlyScalarType.Int8 => unchecked((sbyte)record[property.Offset]),
        PlyScalarType.UInt8 => record[property.Offset],
        PlyScalarType.Int16 => BinaryPrimitives.ReadInt16LittleEndian(record.Slice(property.Offset, 2)),
        PlyScalarType.UInt16 => BinaryPrimitives.ReadUInt16LittleEndian(record.Slice(property.Offset, 2)),
        PlyScalarType.Int32 => BinaryPrimitives.ReadInt32LittleEndian(record.Slice(property.Offset, 4)),
        PlyScalarType.UInt32 => BinaryPrimitives.ReadUInt32LittleEndian(record.Slice(property.Offset, 4)),
        PlyScalarType.Float32 => BitConverter.Int32BitsToSingle(BinaryPrimitives.ReadInt32LittleEndian(record.Slice(property.Offset, 4))),
        PlyScalarType.Float64 => BitConverter.Int64BitsToDouble(BinaryPrimitives.ReadInt64LittleEndian(record.Slice(property.Offset, 8))),
        _ => throw new InvalidDataException("The PLY scalar type is unsupported."),
    };

    private static double ReadAsciiScalar(string token, PlyScalarType type) => type switch
    {
        PlyScalarType.Int8 when sbyte.TryParse(token, NumberStyles.Integer, CultureInfo.InvariantCulture, out sbyte value) => value,
        PlyScalarType.UInt8 when byte.TryParse(token, NumberStyles.Integer, CultureInfo.InvariantCulture, out byte value) => value,
        PlyScalarType.Int16 when short.TryParse(token, NumberStyles.Integer, CultureInfo.InvariantCulture, out short value) => value,
        PlyScalarType.UInt16 when ushort.TryParse(token, NumberStyles.Integer, CultureInfo.InvariantCulture, out ushort value) => value,
        PlyScalarType.Int32 when int.TryParse(token, NumberStyles.Integer, CultureInfo.InvariantCulture, out int value) => value,
        PlyScalarType.UInt32 when uint.TryParse(token, NumberStyles.Integer, CultureInfo.InvariantCulture, out uint value) => value,
        PlyScalarType.Float32 when float.TryParse(token, NumberStyles.Float, CultureInfo.InvariantCulture, out float value) => value,
        PlyScalarType.Float64 when double.TryParse(token, NumberStyles.Float, CultureInfo.InvariantCulture, out double value) => value,
        _ => throw new InvalidDataException("The PLY file contains a vertex value with an invalid scalar type."),
    };

    private static PlyProperty GetRequiredProperty(List<PlyProperty> properties, string name)
    {
        foreach (PlyProperty property in properties)
        {
            if (string.Equals(property.Name, name, StringComparison.Ordinal))
                return property;
        }
        throw new InvalidDataException($"The PLY vertex element is missing required '{name}' coordinates.");
    }

    private static PlyProperty? GetColorProperty(List<PlyProperty> properties, string longName, string shortName)
    {
        foreach (PlyProperty property in properties)
        {
            if (string.Equals(property.Name, longName, StringComparison.Ordinal) ||
                string.Equals(property.Name, shortName, StringComparison.Ordinal))
            {
                return property;
            }
        }
        return null;
    }

    private static bool TryParseScalarType(string name, out PlyScalarType type)
    {
        switch (name.ToLowerInvariant())
        {
            case "char":
            case "int8": type = PlyScalarType.Int8; return true;
            case "uchar":
            case "uint8": type = PlyScalarType.UInt8; return true;
            case "short":
            case "int16": type = PlyScalarType.Int16; return true;
            case "ushort":
            case "uint16": type = PlyScalarType.UInt16; return true;
            case "int":
            case "int32": type = PlyScalarType.Int32; return true;
            case "uint":
            case "uint32": type = PlyScalarType.UInt32; return true;
            case "float":
            case "float32": type = PlyScalarType.Float32; return true;
            case "double":
            case "float64": type = PlyScalarType.Float64; return true;
            default: type = default; return false;
        }
    }

    private static int GetScalarSize(PlyScalarType type) => type switch
    {
        PlyScalarType.Int8 or PlyScalarType.UInt8 => 1,
        PlyScalarType.Int16 or PlyScalarType.UInt16 => 2,
        PlyScalarType.Int32 or PlyScalarType.UInt32 or PlyScalarType.Float32 => 4,
        PlyScalarType.Float64 => 8,
        _ => throw new InvalidDataException("The PLY scalar type is unsupported."),
    };

    private static FileStream OpenStream(string path, FileOptions options) => new(
        path,
        FileMode.Open,
        FileAccess.Read,
        FileShare.ReadWrite,
        bufferSize: 128 * 1024,
        options: options);

    private static string ReadHeaderLine(FileStream stream, byte[] buffer, ref int headerBytes)
    {
        int count = 0;
        while (true)
        {
            int next = stream.ReadByte();
            if (next < 0)
                throw new InvalidDataException("The PLY header ends before end_header.");
            if (++headerBytes > MaximumHeaderBytes)
                throw new InvalidDataException("The PLY header is too large.");
            if (next == '\n')
                break;
            if (next == '\r')
                continue;
            if (count >= buffer.Length)
                throw new InvalidDataException("A PLY header line is too long.");
            buffer[count++] = (byte)next;
        }
        return System.Text.Encoding.ASCII.GetString(buffer, 0, count);
    }

    private static string ReadDataLine(FileStream stream, byte[] buffer)
    {
        int count = 0;
        while (true)
        {
            int next = stream.ReadByte();
            if (next < 0)
                throw new EndOfStreamException("Unexpected end of ASCII PLY vertex data.");
            if (next == '\n')
                break;
            if (next == '\r')
                continue;
            if (count >= buffer.Length)
                throw new InvalidDataException("An ASCII PLY vertex line is too long.");
            buffer[count++] = (byte)next;
        }
        return System.Text.Encoding.ASCII.GetString(buffer, 0, count);
    }

    private static void ReadExactly(FileStream stream, byte[] buffer, int count, string errorMessage)
    {
        int read = 0;
        while (read < count)
        {
            int bytesRead = stream.Read(buffer, read, count - read);
            if (bytesRead == 0)
                throw new EndOfStreamException(errorMessage);
            read += bytesRead;
        }
    }

    private static string ComputeHeaderFingerprint(string path, int byteCount)
    {
        byte[] header = new byte[byteCount];
        using FileStream stream = OpenStream(path, FileOptions.SequentialScan);
        ReadExactly(stream, header, header.Length, "Unexpected end of PLY header.");
        return Convert.ToHexString(SHA256.HashData(header));
    }

    private readonly record struct PlyProperty(string Name, PlyScalarType Type, int Index, int Offset);
}

public enum PlyEncoding
{
    Ascii,
    BinaryLittleEndian,
}

public enum PlyScalarType
{
    Int8,
    UInt8,
    Int16,
    UInt16,
    Int32,
    UInt32,
    Float32,
    Float64,
}

/// <summary>
/// Converts PLY RGB data into the Windows ABGR/COLORREF representation used by Revit.  PLY
/// exporters commonly use pure white to mean "no colour"; that makes an otherwise valid point
/// cloud disappear against Revit's usual white canvas.  Render that sentinel as black instead
/// while retaining every other supplied colour.
/// </summary>
public static class PlyPointColor
{
    private const int RgbMask = 0x00ffffff;
    private const int VisibleFallback = 0x00000000;

    public static int NormalizeForRevit(int color)
    {
        int rgb = color & RgbMask;
        return rgb == RgbMask ? VisibleFallback : rgb;
    }
}

public readonly record struct PlyPoint(double X, double Y, double Z, int Color);
