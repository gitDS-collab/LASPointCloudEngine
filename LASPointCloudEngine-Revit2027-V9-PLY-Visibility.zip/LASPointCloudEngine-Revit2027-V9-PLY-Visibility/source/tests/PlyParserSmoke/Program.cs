using System.Globalization;
using LASPointCloudEngine.Ply;

string root = Path.Combine(Path.GetTempPath(), "LASPointCloudEngine-PlyParserSmoke-" + Guid.NewGuid().ToString("N"));
Directory.CreateDirectory(root);
try
{
    TestAscii(Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "..", "..", "..", "..", "fixtures", "sample-ascii.ply")));
    TestMissingRgbUsesVisibleFallback(Path.Combine(root, "no-rgb.ply"));
    TestBinaryLittleEndian(Path.Combine(root, "sample-binary.ply"));
    TestBigEndianIsRejected(Path.Combine(root, "big-endian.ply"));
    Console.WriteLine("PLY parser ASCII and binary-little-endian smoke tests passed.");
    return 0;
}
finally
{
    if (Directory.Exists(root))
        Directory.Delete(root, recursive: true);
}

static void TestAscii(string path)
{
    PlyFileHeader header = PlyFileHeader.Read(path);
    List<PlyPoint> points = new();
    header.ScanPoints(path, points.Add);
    Require(header.Encoding == PlyEncoding.Ascii && header.VertexCount == 4, "ASCII header was not recognized.");
    Require(points.Count == 4 && points[1] == new PlyPoint(10, 0, 0, 0x0000ff00), "ASCII point/RGB parsing failed.");
    Require(points[3] == new PlyPoint(0, 0, 30, 0x00000000), "Pure-white PLY points were not normalized for a visible Revit display.");
}

static void TestMissingRgbUsesVisibleFallback(string path)
{
    File.WriteAllText(path,
        "ply\nformat ascii 1.0\nelement vertex 1\nproperty float x\nproperty float y\nproperty float z\nend_header\n1 2 3\n",
        System.Text.Encoding.ASCII);
    PlyFileHeader header = PlyFileHeader.Read(path);
    List<PlyPoint> points = new();
    header.ScanPoints(path, points.Add);
    Require(points.Count == 1 && points[0] == new PlyPoint(1, 2, 3, 0x00000000),
        "Uncoloured PLY points were not assigned a visible Revit fallback.");
}

static void TestBinaryLittleEndian(string path)
{
    byte[] header = System.Text.Encoding.ASCII.GetBytes(
        "ply\nformat binary_little_endian 1.0\n" +
        "element vertex 3\n" +
        "property float y\nproperty uchar red\nproperty double x\nproperty float z\n" +
        "property uchar green\nproperty uchar blue\nend_header\n");
    using (FileStream stream = new(path, FileMode.CreateNew, FileAccess.Write, FileShare.None))
    using (BinaryWriter writer = new(stream))
    {
        writer.Write(header);
        WriteVertex(writer, 2.5f, 10, 1.25, -3.5f, 20, 30);
        WriteVertex(writer, 5.0f, 255, -9.0, 7.0f, 0, 128);
        WriteVertex(writer, -1.0f, 0, 0.0, 0.0f, 255, 255);
    }

    PlyFileHeader parsed = PlyFileHeader.Read(path);
    List<PlyPoint> points = new();
    parsed.ScanPoints(path, points.Add);
    Require(parsed.Encoding == PlyEncoding.BinaryLittleEndian && parsed.VertexCount == 3, "Binary PLY header was not recognized.");
    Require(points.Count == 3 && points[0] == new PlyPoint(1.25, 2.5, -3.5, 0x001e140a), "Binary PLY scalar/RGB parsing failed.");
    Require(points[1] == new PlyPoint(-9, 5, 7, 0x008000ff), "Binary PLY point order parsing failed.");
}

static void TestBigEndianIsRejected(string path)
{
    File.WriteAllText(path, "ply\nformat binary_big_endian 1.0\nelement vertex 1\nproperty float x\nproperty float y\nproperty float z\nend_header\n", System.Text.Encoding.ASCII);
    try
    {
        _ = PlyFileHeader.Read(path);
        throw new InvalidOperationException("Binary big-endian PLY unexpectedly passed validation.");
    }
    catch (InvalidDataException exception) when (exception.Message.Contains("big-endian", StringComparison.OrdinalIgnoreCase))
    {
        // Expected: the external cache helper deliberately avoids unsafe byte swapping paths.
    }
}

static void WriteVertex(BinaryWriter writer, float y, byte red, double x, float z, byte green, byte blue)
{
    writer.Write(y);
    writer.Write(red);
    writer.Write(x);
    writer.Write(z);
    writer.Write(green);
    writer.Write(blue);
}

static void Require(bool condition, string message)
{
    if (!condition)
        throw new InvalidOperationException(message);
}
