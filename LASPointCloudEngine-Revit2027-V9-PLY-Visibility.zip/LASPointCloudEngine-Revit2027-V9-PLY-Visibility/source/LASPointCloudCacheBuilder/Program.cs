using System.Buffers.Binary;
using System.Security.Cryptography;
using System.Text;
using LASPointCloudEngine.Ply;

internal static class Program
{
    private const string Magic = "LPCACHE2";
    private const int Version = 2;
    private const string PlyMagic = "PLYPCACHE1";
    private const int PlyCacheVersion = 2;
    private const int PlyHeaderFingerprintLength = 64;
    private const double PlyUnitsToFeet = 3.280839895; // PLY has no standard unit; this tool assumes metres.
    private const int GridResolution = 512;
    private const int SamplesPerCell = 8;
    private const int TargetCachePoints = 1_000_000;
    private const int ReadBlockBytes = 8 * 1024 * 1024;

    private static int Main(string[] args)
    {
        if (args.Length != 1)
        {
            Console.Error.WriteLine("Usage: LASPointCloudCacheBuilder <uncompressed-las-or-ply-file>");
            return 2;
        }

        try
        {
            string sourcePath = Path.GetFullPath(args[0]);
            BuildCache(sourcePath);
            return 0;
        }
        catch (Exception exception)
        {
            Console.Error.WriteLine("Cache build failed: " + exception.Message);
            return 1;
        }
    }

    private static void BuildCache(string sourcePath)
    {
        if ((File.GetAttributes(sourcePath) & FileAttributes.Offline) != 0)
        {
            throw new InvalidDataException(
                "The source file is cloud-only. Choose 'Always keep on this device' before building a cache.");
        }

        string extension = Path.GetExtension(sourcePath);
        if (string.Equals(extension, ".las", StringComparison.OrdinalIgnoreCase))
        {
            BuildLasCache(sourcePath);
            return;
        }
        if (string.Equals(extension, ".ply", StringComparison.OrdinalIgnoreCase))
        {
            BuildPlyCache(sourcePath);
            return;
        }

        throw new InvalidDataException("Choose an uncompressed .las file or a supported .ply file.");
    }

    private static void BuildLasCache(string sourcePath)
    {

        FileInfo sourceInfo = new(sourcePath);
        LasHeaderInfo header = LasHeaderInfo.Read(sourcePath, sourceInfo.Length);
        Console.WriteLine($"Building a dense local preview from {header.PointCount:N0} source points...");

        int cellCount = GridResolution * GridResolution;
        long[] observed = new long[cellCount];
        PackedPoint[] reservoirs = new PackedPoint[checked(cellCount * SamplesPerCell)];
        byte[] block = new byte[ReadBlockBytes + header.RecordLength];
        int recordsPerBlock = Math.Max(1, ReadBlockBytes / header.RecordLength);
        double width = Math.Max(double.Epsilon, header.LocalMaximumX - header.LocalMinimumX);
        double depth = Math.Max(double.Epsilon, header.LocalMaximumY - header.LocalMinimumY);
        long processed = 0;
        int lastPercent = -1;

        using (FileStream stream = new(
            sourcePath,
            FileMode.Open,
            FileAccess.Read,
            FileShare.ReadWrite,
            bufferSize: ReadBlockBytes,
            options: FileOptions.SequentialScan))
        {
            stream.Position = header.PointDataOffset;
            while (processed < header.PointCount)
            {
                int recordsThisBlock = (int)Math.Min(recordsPerBlock, header.PointCount - processed);
                int bytesThisBlock = checked(recordsThisBlock * header.RecordLength);
                ReadExactly(stream, block, bytesThisBlock);

                for (int recordInBlock = 0; recordInBlock < recordsThisBlock; recordInBlock++)
                {
                    int position = recordInBlock * header.RecordLength;
                    PackedPoint point = header.ReadPoint(block.AsSpan(position, header.RecordLength));
                    int xCell = ClampCell((point.X - header.LocalMinimumX) / width);
                    int yCell = ClampCell((point.Y - header.LocalMinimumY) / depth);
                    int cell = yCell * GridResolution + xCell;
                    long count = ++observed[cell];

                    int reservoirOffset = cell * SamplesPerCell;
                    if (count <= SamplesPerCell)
                    {
                        reservoirs[reservoirOffset + (int)count - 1] = point;
                    }
                    else
                    {
                        ulong priority = Mix64((ulong)processed ^ ((ulong)cell * 0x9E3779B97F4A7C15UL));
                        int replacement = (int)(priority % (ulong)count);
                        if (replacement < SamplesPerCell)
                            reservoirs[reservoirOffset + replacement] = point;
                    }

                    processed++;
                }

                int percent = (int)(processed * 100L / header.PointCount);
                if (percent >= lastPercent + 5 || percent == 100)
                {
                    Console.WriteLine($"  {percent}%");
                    lastPercent = percent;
                }
            }
        }

        List<PackedPoint> orderedPoints = BuildSpatiallyBalancedOrder(observed, reservoirs);
        string cachePath = GetCachePath(sourcePath);
        WriteCacheAtomically(cachePath, sourceInfo, header.PointCount, orderedPoints);
        Console.WriteLine($"Ready: {orderedPoints.Count:N0} preview points in {cachePath}");
    }

    private static void BuildPlyCache(string sourcePath)
    {
        FileInfo sourceInfo = new(sourcePath);
        long sourceLength = sourceInfo.Length;
        long sourceWriteTicks = sourceInfo.LastWriteTimeUtc.Ticks;
        PlyFileHeader header = PlyFileHeader.Read(sourcePath);
        Console.WriteLine($"Preparing a safe PLY preview from {header.VertexCount:N0} source vertices ({header.Encoding})...");
        Console.WriteLine("PLY coordinates are assumed to be metres. Faces, normals, textures, and other mesh data are ignored.");

        PlyBounds bounds = new();
        long processed = 0;
        int lastPercent = -1;
        header.ScanPoints(sourcePath, point =>
        {
            bounds.Add(point);
            processed++;
            WriteProgress("  Bounds", processed, header.VertexCount, ref lastPercent);
        });
        if (!bounds.HasPoint)
            throw new InvalidDataException("No readable PLY vertices were found.");

        int cellCount = GridResolution * GridResolution;
        long[] observed = new long[cellCount];
        PackedPoint[] reservoirs = new PackedPoint[checked(cellCount * SamplesPerCell)];
        double width = Math.Max(double.Epsilon, bounds.MaxX - bounds.MinX);
        double depth = Math.Max(double.Epsilon, bounds.MaxY - bounds.MinY);
        processed = 0;
        lastPercent = -1;

        header.ScanPoints(sourcePath, point =>
        {
            PackedPoint localPoint = new(
                ToLocalFloat(point.X, bounds.MinX, "X"),
                ToLocalFloat(point.Y, bounds.MinY, "Y"),
                ToLocalFloat(point.Z, bounds.MinZ, "Z"),
                point.Color);
            int xCell = ClampCell((point.X - bounds.MinX) / width);
            int yCell = ClampCell((point.Y - bounds.MinY) / depth);
            int cell = yCell * GridResolution + xCell;
            long count = ++observed[cell];
            int reservoirOffset = cell * SamplesPerCell;
            if (count <= SamplesPerCell)
            {
                reservoirs[reservoirOffset + (int)count - 1] = localPoint;
            }
            else
            {
                ulong priority = Mix64((ulong)processed ^ ((ulong)cell * 0x9E3779B97F4A7C15UL));
                int replacement = (int)(priority % (ulong)count);
                if (replacement < SamplesPerCell)
                    reservoirs[reservoirOffset + replacement] = localPoint;
            }

            processed++;
            WriteProgress("  Preview", processed, header.VertexCount, ref lastPercent);
        });

        List<PackedPoint> orderedPoints = BuildSpatiallyBalancedOrder(observed, reservoirs);
        EnsurePlySourceUnchanged(sourcePath, sourceLength, sourceWriteTicks, header);
        string cachePath = GetPlyCachePath(sourcePath);
        WritePlyCacheAtomically(cachePath, sourceLength, sourceWriteTicks, header, bounds, orderedPoints);
        Console.WriteLine($"Ready: {orderedPoints.Count:N0} preview points in {cachePath}");
    }

    private static void WritePlyCacheAtomically(
        string cachePath,
        long sourceLength,
        long sourceWriteTicks,
        PlyFileHeader header,
        PlyBounds bounds,
        List<PackedPoint> points)
    {
        string? directory = Path.GetDirectoryName(cachePath);
        if (string.IsNullOrWhiteSpace(directory))
            throw new IOException("The local PLY preview-cache path is invalid.");
        Directory.CreateDirectory(directory);

        string temporaryPath = cachePath + "." + Guid.NewGuid().ToString("N") + ".partial";
        try
        {
            using (FileStream stream = new(
                temporaryPath,
                FileMode.CreateNew,
                FileAccess.Write,
                FileShare.None,
                bufferSize: 1024 * 1024,
                options: FileOptions.SequentialScan))
            using (BinaryWriter writer = new(stream, Encoding.UTF8, leaveOpen: true))
            {
                writer.Write(Encoding.ASCII.GetBytes(PlyMagic));
                writer.Write(PlyCacheVersion);
                writer.Write(sourceLength);
                writer.Write(sourceWriteTicks);
                writer.Write(header.VertexCount);
                byte[] headerFingerprint = Encoding.ASCII.GetBytes(header.HeaderFingerprint);
                if (headerFingerprint.Length != PlyHeaderFingerprintLength)
                    throw new InvalidDataException("The PLY header fingerprint is invalid.");
                writer.Write(headerFingerprint);
                writer.Write(PlyUnitsToFeet);
                writer.Write(bounds.MinX);
                writer.Write(bounds.MinY);
                writer.Write(bounds.MinZ);
                writer.Write(bounds.MaxX);
                writer.Write(bounds.MaxY);
                writer.Write(bounds.MaxZ);
                writer.Write(points.Count);
                foreach (PackedPoint point in points)
                {
                    writer.Write(point.X);
                    writer.Write(point.Y);
                    writer.Write(point.Z);
                    writer.Write(point.Color);
                }
                writer.Flush();
                stream.Flush(flushToDisk: true);
            }

            File.Move(temporaryPath, cachePath, overwrite: true);
        }
        catch
        {
            if (File.Exists(temporaryPath))
                File.Delete(temporaryPath);
            throw;
        }
    }

    private static void WriteProgress(string stage, long processed, long total, ref int lastPercent)
    {
        int percent = (int)Math.Clamp(Math.Floor(processed * 100.0 / total), 0.0, 100.0);
        if (percent >= lastPercent + 5 || percent == 100)
        {
            Console.WriteLine($"{stage} {percent}%");
            lastPercent = percent;
        }
    }

    private static float ToLocalFloat(double value, double origin, string coordinateName)
    {
        double local = value - origin;
        if (!double.IsFinite(local) || local < float.MinValue || local > float.MaxValue)
            throw new InvalidDataException($"The PLY {coordinateName} coordinate is outside Revit's supported preview range.");
        return (float)local;
    }

    private static List<PackedPoint> BuildSpatiallyBalancedOrder(long[] observed, PackedPoint[] reservoirs)
    {
        List<PackedPoint> result = new(Math.Min(TargetCachePoints, reservoirs.Length));
        for (int sampleRank = 0; sampleRank < SamplesPerCell && result.Count < TargetCachePoints; sampleRank++)
        {
            List<RankedCell> cells = new();
            for (int cell = 0; cell < observed.Length; cell++)
            {
                if (observed[cell] > sampleRank)
                {
                    cells.Add(new RankedCell(
                        Mix64(((ulong)(uint)cell << 8) | (uint)sampleRank),
                        cell));
                }
            }

            cells.Sort(static (left, right) => left.Priority.CompareTo(right.Priority));
            foreach (RankedCell cell in cells)
            {
                result.Add(reservoirs[cell.Cell * SamplesPerCell + sampleRank]);
                if (result.Count == TargetCachePoints)
                    break;
            }
        }

        if (result.Count == 0)
            throw new InvalidDataException("No readable point-cloud points were found for the preview cache.");
        return result;
    }

    private static void EnsurePlySourceUnchanged(
        string sourcePath,
        long originalLength,
        long originalWriteTicks,
        PlyFileHeader originalHeader)
    {
        FileInfo currentInfo = new(sourcePath);
        PlyFileHeader currentHeader = PlyFileHeader.Read(sourcePath);
        if (currentInfo.Length != originalLength ||
            currentInfo.LastWriteTimeUtc.Ticks != originalWriteTicks ||
            currentHeader.VertexCount != originalHeader.VertexCount ||
            !string.Equals(currentHeader.HeaderFingerprint, originalHeader.HeaderFingerprint, StringComparison.Ordinal))
        {
            throw new IOException("The PLY source changed while its preview was being prepared. Run the cache builder again after the source finishes changing.");
        }
    }

    private static void WriteCacheAtomically(
        string cachePath,
        FileInfo sourceInfo,
        long sourcePointCount,
        List<PackedPoint> points)
    {
        string? directory = Path.GetDirectoryName(cachePath);
        if (string.IsNullOrWhiteSpace(directory))
            throw new IOException("The local preview-cache path is invalid.");
        Directory.CreateDirectory(directory);

        string temporaryPath = cachePath + "." + Guid.NewGuid().ToString("N") + ".partial";
        try
        {
            using (FileStream stream = new(
                temporaryPath,
                FileMode.CreateNew,
                FileAccess.Write,
                FileShare.None,
                bufferSize: 1024 * 1024,
                options: FileOptions.SequentialScan))
            using (BinaryWriter writer = new(stream, Encoding.UTF8, leaveOpen: true))
            {
                writer.Write(Encoding.ASCII.GetBytes(Magic));
                writer.Write(Version);
                writer.Write(sourceInfo.Length);
                writer.Write(sourceInfo.LastWriteTimeUtc.Ticks);
                writer.Write(sourcePointCount);
                writer.Write(points.Count);
                foreach (PackedPoint point in points)
                {
                    writer.Write(point.X);
                    writer.Write(point.Y);
                    writer.Write(point.Z);
                    writer.Write(point.Color);
                }
                writer.Flush();
                stream.Flush(flushToDisk: true);
            }

            File.Move(temporaryPath, cachePath, overwrite: true);
        }
        catch
        {
            if (File.Exists(temporaryPath))
                File.Delete(temporaryPath);
            throw;
        }
    }

    private static string GetCachePath(string sourcePath)
    {
        string normalized = Path.GetFullPath(sourcePath).ToUpperInvariant();
        byte[] hash = SHA256.HashData(Encoding.UTF8.GetBytes(normalized));
        return Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "LASPointCloudEngine",
            "Cache",
            Convert.ToHexString(hash) + ".lpcache");
    }

    private static string GetPlyCachePath(string sourcePath)
    {
        string normalized = Path.GetFullPath(sourcePath).ToUpperInvariant();
        byte[] hash = SHA256.HashData(Encoding.UTF8.GetBytes(normalized));
        return Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "LASPointCloudEngine",
            "Cache",
            Convert.ToHexString(hash) + ".plypcache");
    }

    private static int ClampCell(double normalized) => Math.Clamp(
        (int)Math.Floor(normalized * GridResolution),
        0,
        GridResolution - 1);

    private static void ReadExactly(FileStream stream, byte[] buffer, int count)
    {
        int read = 0;
        while (read < count)
        {
            int bytesRead = stream.Read(buffer, read, count - read);
            if (bytesRead == 0)
                throw new EndOfStreamException("Unexpected end of LAS point data.");
            read += bytesRead;
        }
    }

    private static ulong Mix64(ulong value)
    {
        value += 0x9E3779B97F4A7C15UL;
        value = (value ^ (value >> 30)) * 0xBF58476D1CE4E5B9UL;
        value = (value ^ (value >> 27)) * 0x94D049BB133111EBUL;
        return value ^ (value >> 31);
    }

    private readonly record struct RankedCell(ulong Priority, int Cell);

    private readonly record struct PackedPoint(float X, float Y, float Z, int Color);

    private sealed class PlyBounds
    {
        public bool HasPoint { get; private set; }
        public double MinX { get; private set; }
        public double MinY { get; private set; }
        public double MinZ { get; private set; }
        public double MaxX { get; private set; }
        public double MaxY { get; private set; }
        public double MaxZ { get; private set; }

        public void Add(PlyPoint point)
        {
            if (!HasPoint)
            {
                MinX = MaxX = point.X;
                MinY = MaxY = point.Y;
                MinZ = MaxZ = point.Z;
                HasPoint = true;
                return;
            }

            MinX = Math.Min(MinX, point.X);
            MinY = Math.Min(MinY, point.Y);
            MinZ = Math.Min(MinZ, point.Z);
            MaxX = Math.Max(MaxX, point.X);
            MaxY = Math.Max(MaxY, point.Y);
            MaxZ = Math.Max(MaxZ, point.Z);
        }
    }

    private sealed class LasHeaderInfo
    {
        private static readonly int[] MinimumRecordLengths = { 20, 28, 26, 34, 57, 63, 30, 36, 38, 59, 67 };
        private static readonly int[] MinimumHeaderLengths = { 227, 227, 227, 235, 375 };

        public long PointDataOffset { get; private init; }
        public int RecordLength { get; private init; }
        public int ColorByteOffset { get; private init; }
        public long PointCount { get; private init; }
        public double ScaleX { get; private init; }
        public double ScaleY { get; private init; }
        public double ScaleZ { get; private init; }
        public double OffsetX { get; private init; }
        public double OffsetY { get; private init; }
        public double OffsetZ { get; private init; }
        public double LocalMinimumX { get; private init; }
        public double LocalMinimumY { get; private init; }
        public double LocalMaximumX { get; private init; }
        public double LocalMaximumY { get; private init; }

        public static LasHeaderInfo Read(string path, long fileLength)
        {
            if (fileLength < 227)
                throw new InvalidDataException("The selected file is too small to contain a LAS header.");

            using FileStream stream = new(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
            using BinaryReader reader = new(stream, Encoding.UTF8, leaveOpen: false);
            if (Encoding.ASCII.GetString(ReadExactly(reader, 4)) != "LASF")
                throw new InvalidDataException("The selected file is not a LAS file.");

            stream.Seek(24, SeekOrigin.Begin);
            byte major = reader.ReadByte();
            byte minor = reader.ReadByte();
            if (major != 1 || minor > 4)
                throw new InvalidDataException("Only LAS 1.0 through 1.4 is supported.");

            stream.Seek(94, SeekOrigin.Begin);
            ushort headerSize = reader.ReadUInt16();
            uint pointDataOffset = reader.ReadUInt32();
            if (headerSize < MinimumHeaderLengths[minor])
                throw new InvalidDataException("The LAS header is incomplete or damaged.");

            stream.Seek(104, SeekOrigin.Begin);
            byte rawFormat = reader.ReadByte();
            if ((rawFormat & 0x80) != 0)
                throw new InvalidDataException("Compressed LAZ data is not supported.");
            int pointFormat = rawFormat & 0x3f;
            ushort recordLength = reader.ReadUInt16();
            uint legacyCount = reader.ReadUInt32();
            if (pointFormat > 10 || recordLength < MinimumRecordLengths[pointFormat])
                throw new InvalidDataException("The LAS point-record format is unsupported or damaged.");
            if (pointDataOffset < headerSize || pointDataOffset >= fileLength)
                throw new InvalidDataException("The LAS point-data offset is invalid.");

            stream.Seek(131, SeekOrigin.Begin);
            double sx = reader.ReadDouble(), sy = reader.ReadDouble(), sz = reader.ReadDouble();
            double ox = reader.ReadDouble(), oy = reader.ReadDouble(), oz = reader.ReadDouble();
            double maxX = reader.ReadDouble(), minX = reader.ReadDouble();
            double maxY = reader.ReadDouble(), minY = reader.ReadDouble();
            _ = reader.ReadDouble();
            _ = reader.ReadDouble();

            if (!double.IsFinite(sx) || !double.IsFinite(sy) || !double.IsFinite(sz) ||
                sx <= 0 || sy <= 0 || sz <= 0 || minX > maxX || minY > maxY)
            {
                throw new InvalidDataException("The LAS coordinates are invalid.");
            }

            long pointCount = legacyCount;
            if (minor == 4)
            {
                if (headerSize < 255)
                    throw new InvalidDataException("The LAS 1.4 extended point count is missing.");
                stream.Seek(247, SeekOrigin.Begin);
                ulong extendedCount = reader.ReadUInt64();
                if (extendedCount > long.MaxValue)
                    throw new InvalidDataException("The LAS point count is too large.");
                if (extendedCount > 0)
                    pointCount = (long)extendedCount;
            }

            long bytesRequired;
            try { bytesRequired = checked(pointCount * (long)recordLength); }
            catch (OverflowException) { throw new InvalidDataException("The LAS point-data size is invalid."); }
            if (pointCount < 1 || bytesRequired > fileLength - pointDataOffset)
                throw new InvalidDataException("The LAS file has no complete readable point records.");

            return new LasHeaderInfo
            {
                PointDataOffset = pointDataOffset,
                RecordLength = recordLength,
                ColorByteOffset = GetColorByteOffset(pointFormat),
                PointCount = pointCount,
                ScaleX = sx,
                ScaleY = sy,
                ScaleZ = sz,
                OffsetX = ox,
                OffsetY = oy,
                OffsetZ = oz,
                LocalMinimumX = minX - ox,
                LocalMinimumY = minY - oy,
                LocalMaximumX = maxX - ox,
                LocalMaximumY = maxY - oy,
            };
        }

        public PackedPoint ReadPoint(ReadOnlySpan<byte> record)
        {
            int x = BinaryPrimitives.ReadInt32LittleEndian(record.Slice(0, 4));
            int y = BinaryPrimitives.ReadInt32LittleEndian(record.Slice(4, 4));
            int z = BinaryPrimitives.ReadInt32LittleEndian(record.Slice(8, 4));
            int color = 0x00ffffff;
            if (ColorByteOffset >= 0)
            {
                ushort red = BinaryPrimitives.ReadUInt16LittleEndian(record.Slice(ColorByteOffset, 2));
                ushort green = BinaryPrimitives.ReadUInt16LittleEndian(record.Slice(ColorByteOffset + 2, 2));
                ushort blue = BinaryPrimitives.ReadUInt16LittleEndian(record.Slice(ColorByteOffset + 4, 2));
                color = (red >> 8) | ((green >> 8) << 8) | ((blue >> 8) << 16);
            }
            return new PackedPoint(
                (float)(x * ScaleX),
                (float)(y * ScaleY),
                (float)(z * ScaleZ),
                color);
        }

        private static int GetColorByteOffset(int pointFormat) => pointFormat switch
        {
            2 => 20,
            3 or 5 => 28,
            7 or 8 or 10 => 30,
            _ => -1,
        };

        private static byte[] ReadExactly(BinaryReader reader, int count)
        {
            byte[] bytes = reader.ReadBytes(count);
            if (bytes.Length != count)
                throw new EndOfStreamException("Unexpected end of LAS header.");
            return bytes;
        }
    }
}
