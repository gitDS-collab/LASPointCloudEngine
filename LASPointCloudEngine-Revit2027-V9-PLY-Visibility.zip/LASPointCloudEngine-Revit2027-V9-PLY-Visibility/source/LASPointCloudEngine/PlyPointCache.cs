using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.PointClouds;
using LASPointCloudEngine.Ply;

namespace LASPointCloudEngine;

/// <summary>
/// The safe, local preview created for a PLY source file.  A PLY file has no standard spatial
/// index, bounds, origin, or unit declaration, so the external cache builder calculates those
/// facts before Revit ever asks this engine to draw the link.
/// </summary>
public sealed class PlyPointCache
{
    private const string Magic = "PLYPCACHE1";
    private const int Version = 2;
    private const int HeaderFingerprintLength = 64;
    private const int MaximumPointCount = 1_000_000;
    private const double MetresToFeet = 3.280839895;

    private readonly CloudPoint[] _points;

    private PlyPointCache(
        CloudPoint[] points,
        double unitsToFeet,
        XYZ offset,
        XYZ localMaximum)
    {
        _points = points;
        UnitsToFeet = unitsToFeet;
        Offset = offset;
        LocalMaximum = localMaximum;
    }

    public int Count => _points.Length;
    public double UnitsToFeet { get; }
    public XYZ Offset { get; }
    public XYZ LocalMinimum => new(0, 0, 0);
    public XYZ LocalMaximum { get; }

    public CloudPoint GetPoint(int index) => _points[index];

    /// <summary>
    /// Tests cache freshness without allocating the preview point array.  This is used by the
    /// import command to decide whether it must launch the external PLY cache builder.
    /// </summary>
    public static bool IsCurrent(string sourcePath, PlyFileHeader header) =>
        TryReadMetadata(sourcePath, header, out _);

    public static PlyPointCache? TryLoad(string sourcePath, PlyFileHeader header)
    {
        try
        {
            if (!TryReadMetadata(sourcePath, header, out CacheMetadata metadata))
                return null;

            using FileStream stream = OpenCacheStream(GetCachePath(sourcePath));
            using BinaryReader reader = new(stream, Encoding.UTF8, leaveOpen: false);
            if (!ReadMetadata(reader, stream, sourcePath, header, out metadata))
                return null;

            long bytesRequired = checked((long)metadata.PointCount * 16L);
            if (stream.Length - stream.Position != bytesRequired)
                return null;

            CloudPoint[] points = new CloudPoint[metadata.PointCount];
            double cachedMaximumX = 0;
            double cachedMaximumY = 0;
            double cachedMaximumZ = 0;
            for (int index = 0; index < points.Length; index++)
            {
                float x = reader.ReadSingle();
                float y = reader.ReadSingle();
                float z = reader.ReadSingle();
                int color = reader.ReadInt32();
                if (!IsValidLocalPoint(x, metadata.MaximumX - metadata.MinimumX) ||
                    !IsValidLocalPoint(y, metadata.MaximumY - metadata.MinimumY) ||
                    !IsValidLocalPoint(z, metadata.MaximumZ - metadata.MinimumZ) ||
                    (color & unchecked((int)0xFF000000)) != 0)
                    return null;
                // Older preview caches were written before white/no-colour PLY vertices were
                // normalized.  Normalize again here so existing project links become visible
                // after upgrading without forcing the user to rebuild their cache.
                points[index] = new CloudPoint(x, y, z, PlyPointColor.NormalizeForRevit(color));
                cachedMaximumX = Math.Max(cachedMaximumX, x);
                cachedMaximumY = Math.Max(cachedMaximumY, y);
                cachedMaximumZ = Math.Max(cachedMaximumZ, z);
            }

            XYZ offset = new(metadata.MinimumX, metadata.MinimumY, metadata.MinimumZ);
            XYZ localMaximum = new(
                Math.Max(metadata.MaximumX - metadata.MinimumX, cachedMaximumX),
                Math.Max(metadata.MaximumY - metadata.MinimumY, cachedMaximumY),
                Math.Max(metadata.MaximumZ - metadata.MinimumZ, cachedMaximumZ));
            return new PlyPointCache(points, metadata.UnitsToFeet, offset, localMaximum);
        }
        catch
        {
            // A moved, stale, corrupt, or interrupted cache must never escape a Revit display
            // callback. The caller can rebuild it outside Revit and retry the link.
            return null;
        }
    }

    public static string GetCachePath(string sourcePath)
    {
        string normalized = Path.GetFullPath(sourcePath).ToUpperInvariant();
        byte[] hash = SHA256.HashData(Encoding.UTF8.GetBytes(normalized));
        string filename = Convert.ToHexString(hash) + ".plypcache";
        return Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "LASPointCloudEngine",
            "Cache",
            filename);
    }

    private static bool TryReadMetadata(string sourcePath, PlyFileHeader header, out CacheMetadata metadata)
    {
        metadata = default;
        try
        {
            string cachePath = GetCachePath(sourcePath);
            if (!File.Exists(cachePath))
                return false;

            using FileStream stream = OpenCacheStream(cachePath);
            using BinaryReader reader = new(stream, Encoding.UTF8, leaveOpen: false);
            return ReadMetadata(reader, stream, sourcePath, header, out metadata);
        }
        catch
        {
            return false;
        }
    }

    private static bool ReadMetadata(
        BinaryReader reader,
        FileStream stream,
        string sourcePath,
        PlyFileHeader header,
        out CacheMetadata metadata)
    {
        metadata = default;
        FileInfo source = new(sourcePath);
        byte[] magic = reader.ReadBytes(Magic.Length);
        if (magic.Length != Magic.Length || Encoding.ASCII.GetString(magic) != Magic ||
            reader.ReadInt32() != Version)
        {
            return false;
        }

        long sourceLength = reader.ReadInt64();
        long sourceWriteTicks = reader.ReadInt64();
        long sourceVertexCount = reader.ReadInt64();
        byte[] fingerprintBytes = reader.ReadBytes(HeaderFingerprintLength);
        if (fingerprintBytes.Length != HeaderFingerprintLength)
            return false;
        string fingerprint = Encoding.ASCII.GetString(fingerprintBytes);
        double unitsToFeet = reader.ReadDouble();
        double minimumX = reader.ReadDouble();
        double minimumY = reader.ReadDouble();
        double minimumZ = reader.ReadDouble();
        double maximumX = reader.ReadDouble();
        double maximumY = reader.ReadDouble();
        double maximumZ = reader.ReadDouble();
        int pointCount = reader.ReadInt32();

        double extentX = maximumX - minimumX;
        double extentY = maximumY - minimumY;
        double extentZ = maximumZ - minimumZ;
        if (sourceLength != source.Length ||
            sourceWriteTicks != source.LastWriteTimeUtc.Ticks ||
            sourceVertexCount != header.VertexCount ||
            !string.Equals(fingerprint, header.HeaderFingerprint, StringComparison.Ordinal) ||
            pointCount < 1 || pointCount > MaximumPointCount ||
            !double.IsFinite(unitsToFeet) || Math.Abs(unitsToFeet - MetresToFeet) > 0.000000001 ||
            !double.IsFinite(minimumX) || !double.IsFinite(minimumY) || !double.IsFinite(minimumZ) ||
            !double.IsFinite(maximumX) || !double.IsFinite(maximumY) || !double.IsFinite(maximumZ) ||
            maximumX < minimumX || maximumY < minimumY || maximumZ < minimumZ ||
            !double.IsFinite(extentX) || !double.IsFinite(extentY) || !double.IsFinite(extentZ) ||
            extentX > float.MaxValue || extentY > float.MaxValue || extentZ > float.MaxValue)
        {
            return false;
        }

        long bytesRequired = checked((long)pointCount * 16L);
        if (stream.Length - stream.Position != bytesRequired)
            return false;

        metadata = new CacheMetadata(
            pointCount,
            unitsToFeet,
            minimumX,
            minimumY,
            minimumZ,
            maximumX,
            maximumY,
            maximumZ);
        return true;
    }

    private static bool IsValidLocalPoint(float value, double maximum)
    {
        if (!float.IsFinite(value))
            return false;

        // Cached vertices are floats, so let the last bit of a rounded source maximum fall just
        // outside its exact double bound without accepting a materially out-of-bounds cache.
        double tolerance = Math.Max(0.001, Math.Abs(maximum) * 0.000001);
        return value >= 0 && value <= maximum + tolerance;
    }

    private static FileStream OpenCacheStream(string cachePath) => new(
        cachePath,
        FileMode.Open,
        FileAccess.Read,
        FileShare.ReadWrite | FileShare.Delete,
        bufferSize: 256 * 1024,
        options: FileOptions.SequentialScan);

    private readonly record struct CacheMetadata(
        int PointCount,
        double UnitsToFeet,
        double MinimumX,
        double MinimumY,
        double MinimumZ,
        double MaximumX,
        double MaximumY,
        double MaximumZ);
}
