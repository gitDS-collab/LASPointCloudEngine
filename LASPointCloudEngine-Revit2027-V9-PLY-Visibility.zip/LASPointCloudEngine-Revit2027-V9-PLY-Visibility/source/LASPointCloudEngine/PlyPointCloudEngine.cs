using System;
using System.IO;
using System.Runtime.CompilerServices;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.PointClouds;
using LASPointCloudEngine.Ply;

namespace LASPointCloudEngine;

/// <summary>
/// A file-based Revit point-cloud engine for prepared PLY vertex clouds. It intentionally reads
/// only the immutable local preview cache in Revit callbacks; the external helper does every full
/// PLY scan before the link is created.
/// </summary>
public sealed class PlyEngine : IPointCloudEngine
{
    public IPointCloudAccess CreatePointCloudAccess(string identifier) => new PlyPointCloudAccess(identifier);
    public void Free() { }
}

public sealed class PlyPointCloudAccess : IPointCloudAccess
{
    private const int DefaultCachedBudget = 160_000;
    private const int MaximumCachedBudget = 200_000;
    private const int MaximumCachedDirectQueryPoints = 25_000;

    private readonly string _path;
    private readonly PlyPointCache _cache;
    private readonly object _directReadLock = new();
    private PlyPointQuery? _directQuery;
    private DirectQueryKey _directQueryKey;
    private bool _hasDirectQuery;
    private bool _freed;

    public PlyPointCloudAccess(string path)
    {
        _path = path;
        PlyFileHeader header = PlyFileHeader.Read(path);
        _cache = PlyPointCache.TryLoad(path, header) ?? throw new InvalidDataException(
            "No current PLY preview cache was found. Use Import LAS / PLY Point Cloud, choose " +
            "Start PLY Preview Cache Builder, wait for it to report Ready, then import this PLY again.");
    }

    public double GetUnitsToFeetConversionFactor() => _cache.UnitsToFeet;
    public XYZ GetOffset() => _cache.Offset;
    public Outline GetExtent() => new(_cache.LocalMinimum, _cache.LocalMaximum);
    public string GetName() => Path.GetFileName(_path);
    public PointCloudColorEncoding GetColorEncoding() => PointCloudColorEncoding.ABGR;

    public IPointSetIterator CreatePointSetIterator(PointCloudFilter filter, double density, ElementId viewId) =>
        CreateIterator(filter, GetRenderBudget(density));

    public IPointSetIterator CreatePointSetIterator(PointCloudFilter filter, ElementId viewId) =>
        CreateIterator(filter, GetDefaultDisplayBudget());

    public unsafe int ReadPoints(PointCloudFilter filter, ElementId viewId, IntPtr buffer, int maximumPoints)
    {
        if (buffer == IntPtr.Zero || maximumPoints <= 0)
            return 0;

        try
        {
            lock (_directReadLock)
            {
                if (_freed)
                    return 0;

                DirectQueryKey key = new(filter, viewId?.Value ?? ElementId.InvalidElementId.Value);
                if (!_hasDirectQuery || !_directQueryKey.Equals(key))
                {
                    _directQuery?.Dispose();
                    _directQuery = new PlyPointQuery(
                        _cache,
                        filter,
                        MaximumCachedDirectQueryPoints,
                        MaximumCachedDirectQueryPoints);
                    _directQueryKey = key;
                    _hasDirectQuery = true;
                }

                return _directQuery!.ReadPoints(buffer, maximumPoints);
            }
        }
        catch
        {
            // Rendering callbacks must not allow a damaged cache or a filter exception to take
            // down Revit's graphics pipeline.
            return 0;
        }
    }

    public void Free()
    {
        lock (_directReadLock)
        {
            _freed = true;
            _directQuery?.Dispose();
            _directQuery = null;
            _hasDirectQuery = false;
        }
    }

    private IPointSetIterator CreateIterator(PointCloudFilter? filter, int renderBudget)
    {
        try
        {
            if (_freed)
                return EmptyPointSetIterator.Instance;
            return new PlyPointSetIterator(new PlyPointQuery(_cache, filter, renderBudget, renderBudget));
        }
        catch
        {
            return EmptyPointSetIterator.Instance;
        }
    }

    private int GetRenderBudget(double density)
    {
        int defaultBudget = GetDefaultDisplayBudget();
        if (!double.IsFinite(density) || density <= 0)
            return defaultBudget;

        // Density is expressed in native point-cloud units. All PLY cached points and the local
        // extent are in the original PLY coordinate system (documented here as metres).
        double width = Math.Max(1.0, _cache.LocalMaximum.X);
        double depth = Math.Max(1.0, _cache.LocalMaximum.Y);
        double requested = density * width * depth;
        if (!double.IsFinite(requested))
            return MaximumCachedBudget;

        return (int)Math.Clamp(
            Math.Max((double)defaultBudget, Math.Ceiling(requested)),
            1.0,
            (double)MaximumCachedBudget);
    }

    private int GetDefaultDisplayBudget() => Math.Min(DefaultCachedBudget, _cache.Count);

    private readonly struct DirectQueryKey : IEquatable<DirectQueryKey>
    {
        private readonly PointCloudFilter? _filter;
        private readonly long _viewId;

        public DirectQueryKey(PointCloudFilter? filter, long viewId)
        {
            _filter = filter;
            _viewId = viewId;
        }

        public bool Equals(DirectQueryKey other) =>
            ReferenceEquals(_filter, other._filter) && _viewId == other._viewId;

        public override bool Equals(object? obj) => obj is DirectQueryKey other && Equals(other);

        public override int GetHashCode() => HashCode.Combine(
            _filter is null ? 0 : RuntimeHelpers.GetHashCode(_filter), _viewId);
    }
}

public sealed class PlyPointSetIterator : IPointSetIterator
{
    private PlyPointQuery? _query;

    public PlyPointSetIterator(PlyPointQuery query) => _query = query;

    public unsafe int ReadPoints(IntPtr buffer, int maximumPoints)
    {
        try { return _query?.ReadPoints(buffer, maximumPoints) ?? 0; }
        catch { return 0; }
    }

    public void Free()
    {
        _query?.Dispose();
        _query = null;
    }
}

/// <summary>
/// A bounded cache-only point stream. It never opens or scans the raw PLY file after the engine
/// is created, so a large ASCII PLY cannot block Revit's UI during a render callback.
/// </summary>
public sealed class PlyPointQuery : IDisposable
{
    private readonly PlyPointCache _cache;
    private readonly PointCloudFilter? _filter;
    private readonly int _maximumCandidates;
    private readonly int _maximumReturned;
    private readonly object _readLock = new();
    private FilterMode _filterMode;
    private bool _filterInitialized;
    private int _nextPoint;
    private int _examined;
    private int _returned;

    public bool IsComplete { get; private set; }

    public PlyPointQuery(
        PlyPointCache cache,
        PointCloudFilter? filter,
        int maximumReturned,
        int maximumCandidates)
    {
        _cache = cache;
        _filter = filter;
        _maximumReturned = Math.Clamp(maximumReturned, 1, cache.Count);
        _maximumCandidates = Math.Clamp(maximumCandidates, _maximumReturned, cache.Count);

        _filterMode = filter is null ? FilterMode.AcceptAll : FilterMode.TestEveryPoint;
        _filterInitialized = filter is null;
    }

    public unsafe int ReadPoints(IntPtr buffer, int maximumPoints)
    {
        if (buffer == IntPtr.Zero || maximumPoints <= 0)
            return 0;

        lock (_readLock)
        {
            if (IsComplete)
                return 0;
            PrepareFilterForRead();
            if (IsComplete)
                return 0;

            CloudPoint* destination = (CloudPoint*)buffer.ToPointer();
            int written = 0;
            int writable = Math.Min(maximumPoints, _maximumReturned - _returned);
            while (_examined < _maximumCandidates &&
                   _nextPoint < _cache.Count &&
                   written < writable)
            {
                CloudPoint point = _cache.GetPoint(_nextPoint++);
                _examined++;
                if (_filterMode != FilterMode.TestEveryPoint || _filter!.TestPoint(point))
                {
                    destination[written++] = point;
                    _returned++;
                }
            }

            if (_examined >= _maximumCandidates ||
                _nextPoint >= _cache.Count ||
                _returned >= _maximumReturned)
            {
                IsComplete = true;
            }
            return written;
        }
    }

    public void Dispose()
    {
        lock (_readLock)
        {
            IsComplete = true;
        }
    }

    private void PrepareFilterForRead()
    {
        if (!_filterInitialized)
        {
            int cellResult = _filter!.TestCell(_cache.LocalMinimum, _cache.LocalMaximum);
            _filterInitialized = true;
            if (cellResult < 0)
            {
                _filterMode = FilterMode.RejectAll;
                IsComplete = true;
                return;
            }
            if (cellResult > 0)
            {
                _filterMode = FilterMode.AcceptAll;
                return;
            }
            _filterMode = FilterMode.TestEveryPoint;
        }

        if (_filterMode == FilterMode.TestEveryPoint)
        {
            // Revit can defer iterator reads until after CreatePointSetIterator returns.
            // Prepare the filter immediately before TestPoint calls so its native state is
            // valid for this display batch rather than relying on constructor-time state.
            int remainingCandidates = _maximumCandidates - _examined;
            _filter!.PrepareForCell(
                _cache.LocalMinimum,
                _cache.LocalMaximum,
                Math.Max(1, remainingCandidates));
        }
    }

    private enum FilterMode
    {
        RejectAll,
        AcceptAll,
        TestEveryPoint,
    }
}
